#!/usr/bin/env bash

echo "hook:defaults::configure:triggered"

echo "configure in defaults/ triggered"
