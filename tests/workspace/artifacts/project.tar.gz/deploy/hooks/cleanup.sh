#!/usr/bin/env bash

echo "hook:cleanup:triggered"

printenv
