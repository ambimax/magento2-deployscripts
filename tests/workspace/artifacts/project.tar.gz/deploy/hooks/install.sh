#!/usr/bin/env bash

echo "hook:install:triggered"

printenv
