#!/usr/bin/env bash

echo "hook:post-install:triggered"

printenv
