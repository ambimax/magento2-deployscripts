#!/usr/bin/env bash

echo "hook:pre-install:triggered"

printenv
