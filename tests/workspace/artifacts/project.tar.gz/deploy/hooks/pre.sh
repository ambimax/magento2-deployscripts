#!/usr/bin/env bash

echo "hook:pre:triggered"

printenv
