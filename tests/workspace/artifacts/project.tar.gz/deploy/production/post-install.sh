#!/usr/bin/env bash

echo "hook:post-installation:triggered"

echo "Is production environment"
