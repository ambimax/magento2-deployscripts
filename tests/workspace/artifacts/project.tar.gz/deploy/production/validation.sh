#!/usr/bin/env bash

echo "hook:validation:triggered"

echo "Is production environment"
