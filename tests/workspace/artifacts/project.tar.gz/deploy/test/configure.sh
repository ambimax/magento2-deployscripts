#!/usr/bin/env bash

echo "hook:configure:triggered"

printenv
